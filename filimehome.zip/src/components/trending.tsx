import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { FaChevronRight } from 'react-icons/fa';
import MovieCard from './moviecard';
import { useSupabaseQuery } from '../hooks/useSupabaseQuery';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';

dayjs.extend(relativeTime);

interface Movie {
  id: string;
  title: string;
  year: string;
  price: string;
  poster: string;
}

interface RawMovie {
  id: string;
  title: string;
  poster?: string | null;
  image?: string | null;
  modifiedAt: string;
  narrator: string;
  genres: string[];
  trending_order?: number | null;
}

interface Props {
  genres?: string[];
  /** Exact narrator names, e.g. 'Rocky'. */
  narrators?: string[];
  title?: string | null;
}

const SKELETON_COUNT = 6;

const MovieSwiper: React.FC<Props> = ({ genres = [], narrators = [], title = 'New Movies' }) => {
  const queryKey =
    'movies:swiper' +
    (genres.length > 0 ? `:${genres.join(',')}` : '') +
    (narrators.length > 0 ? `:n=${narrators.join(',')}` : '');

  const { data, isLoading } = useSupabaseQuery<Movie[]>(
    queryKey,
    async (client) => {
      let baseQuery = client
        .from('moviesv2')
        .select('id, title, poster, image, modifiedAt, narrator, genres, trending_order')
        .order('trending_order', { ascending: true, nullsFirst: false })
        .order('modifiedAt', { ascending: false })
        .limit(12);

      if (genres.length > 0 && genres[0] !== 'All') {
        baseQuery = baseQuery.overlaps('genres', genres);
      }
      if (narrators.length > 0) {
        baseQuery = baseQuery.in('narrator', narrators);
      }

      const { data, error } = await baseQuery;
      if (error) throw error;

      const transformed = (data as RawMovie[]).map((movie) => ({
        id: movie.id,
        title: movie.title,
        year: dayjs(movie.modifiedAt).fromNow(),
        price: movie.narrator || 'Unknown narrator',
        poster: movie.poster || movie.image || '/fallback.jpg',
      }));

      return {
        data: transformed,
        error: null,
        count: undefined,
      };
    }
  );

  const renderSkeletonSlides = () => (
    [...Array(SKELETON_COUNT)].map((_, idx) => (
      <SwiperSlide key={`skeleton-${idx}`}>
        <div className="animate-pulse bg-gray-700 rounded-lg w-full h-48 flex flex-col p-3">
          <div className="bg-gray-600 rounded-md h-32 w-full mb-3" />
          <div className="h-4 bg-gray-600 rounded w-3/4 mb-2" />
          <div className="h-3 bg-gray-600 rounded w-1/2" />
        </div>
      </SwiperSlide>
    ))
  );

  return (
    <section className="my-6">
      <h2 className="font-bold text-xlarge text-white">
        {title} <FaChevronRight className="inline-block text-yellow-200" />
      </h2>

      <div className="container mx-auto py-8">
        {isLoading ? (
          <Swiper
            spaceBetween={12}
            breakpoints={{
              0: { slidesPerView: 3 },
              768: { slidesPerView: 4 },
              1024: { slidesPerView: 6 },
            }}
            className="mySwiper"
          >
            {renderSkeletonSlides()}
          </Swiper>
        ) : (data?.data?.length ?? 0) === 0 ? (
          <p className="text-gray-400 py-6">No movies in this section yet.</p>
        ) : (
          <Swiper
            spaceBetween={12}
            loop
            autoplay={{ delay: 4000, disableOnInteraction: false }}
            breakpoints={{
              0: { slidesPerView: 3 },
              768: { slidesPerView: 4 },
              1024: { slidesPerView: 6 },
            }}
            className="mySwiper"
          >
            {data?.data?.map((movie) => (
              <SwiperSlide key={movie.id}>
                <MovieCard movie={movie} />
              </SwiperSlide>
            ))}
          </Swiper>
        )}
      </div>
    </section>
  );
};

export default MovieSwiper;
